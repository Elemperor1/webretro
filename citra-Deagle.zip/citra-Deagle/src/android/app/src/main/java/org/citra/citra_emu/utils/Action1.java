package org.citra.citra_emu.utils;

public interface Action1<T> {
    void call(T t);
}
